import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ShoppingBag, ShoppingCart, User, Search, Menu, LogOut } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';
import { useAuth } from '../../contexts/AuthContext';
import './Header.css';

const Header = () => {
    const { cartCount } = useCart();
    const { user, logout, isAuthenticated } = useAuth();

    return (
        <header className="header">
            <div className="container header__container">
                <Link to="/" className="header__logo">
                    <ShoppingBag className="header__logo-icon" size={28} />
                    <span className="header__logo-text">LuxeStore</span>
                </Link>

                <nav className="header__nav">
                    <ul className="header__nav-list">
                        <li>
                            <NavLink to="/" className={({ isActive }) => isActive ? "header__nav-link active" : "header__nav-link"}>
                                Home
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/shop" className={({ isActive }) => isActive ? "header__nav-link active" : "header__nav-link"}>
                                Shop
                            </NavLink>
                        </li>
                    </ul>
                </nav>

                <div className="header__actions">
                    <button className="header__action-btn" aria-label="Search">
                        <Search size={22} />
                    </button>

                    {isAuthenticated ? (
                        <div className="header__user-menu">
                            <button className="header__action-btn" title={`Logout ${user.name}`} onClick={logout}>
                                <LogOut size={22} />
                            </button>
                        </div>
                    ) : (
                        <Link to="/login" className="header__action-btn" aria-label="Login">
                            <User size={22} />
                        </Link>
                    )}

                    <Link to="/cart" className="header__action-btn header__cart-btn" aria-label="Cart">
                        <ShoppingCart size={22} />
                        <span className="header__cart-count">{cartCount}</span>
                    </Link>
                    <button className="header__mobile-menu-btn" aria-label="Menu">
                        <Menu size={24} />
                    </button>
                </div>
            </div>
        </header>
    );
};

export default Header;
