import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container footer__container">
                <div className="footer__brand">
                    <Link to="/" className="footer__logo">
                        <ShoppingBag size={24} />
                        <span>LuxeStore</span>
                    </Link>
                    <p className="footer__desc">
                        Premium e-commerce experience for the modern aesthetic enthusiast. Discover curated luxury across categories.
                    </p>
                    <div className="footer__socials">
                        <a href="#"><Facebook size={20} /></a>
                        <a href="#"><Twitter size={20} /></a>
                        <a href="#"><Instagram size={20} /></a>
                        <a href="#"><Youtube size={20} /></a>
                    </div>
                </div>

                <div className="footer__links">
                    <h4>Shop</h4>
                    <ul>
                        <li><Link to="/shop">All Products</Link></li>
                        <li><Link to="/shop?cat=electronics">Electronics</Link></li>
                        <li><Link to="/shop?cat=fashion">Fashion</Link></li>
                        <li><Link to="/shop?cat=jewelry">Jewelry</Link></li>
                    </ul>
                </div>

                <div className="footer__links">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Shipping Policy</a></li>
                        <li><a href="#">Returns & Exchanges</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div className="footer__contact">
                    <h4>Get in Touch</h4>
                    <div className="contact-item">
                        <MapPin size={18} />
                        <span>123 Design Blvd, New York, NY 10001</span>
                    </div>
                    <div className="contact-item">
                        <Phone size={18} />
                        <span>+1 (555) 123-4567</span>
                    </div>
                    <div className="contact-item">
                        <Mail size={18} />
                        <span>support@luxestore.com</span>
                    </div>
                </div>
            </div>

            <div className="footer__bottom container">
                <p>&copy; 2026 LuxeStore by Antigravity AI. All rights reserved.</p>
                <div className="footer__payments">
                    <span>Secure Payments:</span>
                    {/* Payment icons would go here */}
                    <div className="payment-icons">
                        <div className="icon-box">Visa</div>
                        <div className="icon-box">MC</div>
                        <div className="icon-box">Amex</div>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
