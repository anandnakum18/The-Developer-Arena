import React from 'react';
import { Star, ShoppingCart } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';
import { useNavigate } from 'react-router-dom';
import './ProductCard.css';

const ProductCard = ({ product }) => {
  const { id, title, price, image, category, rating } = product;
  const { addToCart } = useCart();
  const navigate = useNavigate();

  return (
    <div className="product-card fade-in" onClick={() => navigate(`/product/${id}`)} style={{ cursor: 'pointer' }}>
      <div className="product-card__image-container">
        <img src={image} alt={title} className="product-card__image" loading="lazy" />
        <span className="product-card__category">{category}</span>
      </div>

      <div className="product-card__content">
        <h3 className="product-card__title" title={title}>{title}</h3>

        <div className="product-card__rating">
          <div className="product-card__stars">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={14}
                fill={i < Math.round(rating.rate) ? "var(--color-primary)" : "transparent"}
                color={i < Math.round(rating.rate) ? "var(--color-primary)" : "var(--color-text-light)"}
              />
            ))}
          </div>
          <span className="product-card__count">({rating.count})</span>
        </div>

        <div className="product-card__footer">
          <span className="product-card__price">${price.toFixed(2)}</span>
          <button
            className="product-card__add-btn"
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product);
            }}
            aria-label="Add to cart"
          >
            <ShoppingCart size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
