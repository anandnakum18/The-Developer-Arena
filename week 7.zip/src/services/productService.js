const BASE_URL = 'https://fakestoreapi.com';

export const ProductService = {
    async getAllProducts() {
        try {
            const response = await fetch(`${BASE_URL}/products`);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error('Error fetching products:', error);
            throw error;
        }
    },

    async getProductById(id) {
        try {
            const response = await fetch(`${BASE_URL}/products/${id}`);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error(`Error fetching product ${id}:`, error);
            throw error;
        }
    },

    async getCategories() {
        try {
            const response = await fetch(`${BASE_URL}/products/categories`);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error('Error fetching categories:', error);
            throw error;
        }
    },

    async getProductsByCategory(category) {
        try {
            const response = await fetch(`${BASE_URL}/products/category/${category}`);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error(`Error fetching products for category ${category}:`, error);
            throw error;
        }
    }
};
