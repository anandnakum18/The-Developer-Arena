import React, { useState, useEffect } from 'react';
import { ProductService } from '../services/productService';
import ProductCard from '../components/product/ProductCard';
import { Search, Filter, ChevronDown } from 'lucide-react';
import './Shop.css';

const Shop = () => {
    const [products, setProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [sortBy, setSortBy] = useState('relevant');
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            setLoading(true);
            const [productsData, categoriesData] = await Promise.all([
                ProductService.getAllProducts(),
                ProductService.getCategories()
            ]);
            setProducts(productsData);
            setCategories(categoriesData);
            setLoading(false);
        } catch (err) {
            setError('Failed to fetch data. Please try again later.');
            setLoading(false);
        }
    };

    const filteredProducts = products
        .filter(p => selectedCategory === 'all' || p.category === selectedCategory)
        .filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()))
        .sort((a, b) => {
            if (sortBy === 'price-low') return a.price - b.price;
            if (sortBy === 'price-high') return b.price - a.price;
            if (sortBy === 'rating') return b.rating.rate - a.rating.rate;
            return 0;
        });

    if (loading) {
        return (
            <div className="container section shop-loading">
                <div className="loader"></div>
                <p>Discovering premium products...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="container section shop-error">
                <p>{error}</p>
                <button onClick={fetchData} className="btn-retry">Try Again</button>
            </div>
        );
    }

    return (
        <div className="shop-page container section fade-in">
            <div className="shop-header">
                <h1 className="shop-title">Discover Our Collection</h1>
                <p className="shop-subtitle">Find high-quality items curated just for you.</p>
            </div>

            <div className="shop-controls">
                <div className="search-box">
                    <Search size={18} color="var(--color-text-light)" />
                    <input
                        type="text"
                        placeholder="Search products..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>

                <div className="filters">
                    <div className="filter-group">
                        <Filter size={16} />
                        <select
                            value={selectedCategory}
                            onChange={(e) => setSelectedCategory(e.target.value)}
                            className="filter-select"
                        >
                            <option value="all">All Categories</option>
                            {categories.map(cat => (
                                <option key={cat} value={cat}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</option>
                            ))}
                        </select>
                        <ChevronDown size={14} className="select-icon" />
                    </div>

                    <div className="filter-group">
                        <span>Sort By:</span>
                        <select
                            value={sortBy}
                            onChange={(e) => setSortBy(e.target.value)}
                            className="filter-select"
                        >
                            <option value="relevant">Relevant</option>
                            <option value="price-low">Price: Low to High</option>
                            <option value="price-high">Price: High to Low</option>
                            <option value="rating">Top Rated</option>
                        </select>
                        <ChevronDown size={14} className="select-icon" />
                    </div>
                </div>
            </div>

            <div className="results-info">
                <p>Showing {filteredProducts.length} results</p>
            </div>

            {filteredProducts.length > 0 ? (
                <div className="product-grid">
                    {filteredProducts.map(product => (
                        <ProductCard
                            key={product.id}
                            product={product}
                        />
                    ))}
                </div>
            ) : (
                <div className="no-results">
                    <h3>No products found</h3>
                    <p>Try adjusting your filters or search query.</p>
                </div>
            )}
        </div>
    );
};

export default Shop;
