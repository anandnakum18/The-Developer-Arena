import React from 'react';
import { useCart } from '../contexts/CartContext';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import './CartPage.css';

const CartPage = () => {
    const { cartItems, removeFromCart, updateQuantity, cartTotal } = useCart();

    if (cartItems.length === 0) {
        return (
            <div className="container section cart-empty fade-in">
                <ShoppingBag size={80} color="var(--color-border)" />
                <h2>Your cart is empty</h2>
                <p>Looks like you haven't added anything to your cart yet.</p>
                <Link to="/shop" className="btn-primary">Start Shopping</Link>
            </div>
        );
    }

    return (
        <div className="container section cart-page fade-in">
            <h1 className="cart-title">Shopping Cart</h1>

            <div className="cart-layout">
                <div className="cart-items">
                    {cartItems.map(item => (
                        <div key={item.id} className="cart-item">
                            <div className="cart-item__image">
                                <img src={item.image} alt={item.title} />
                            </div>
                            <div className="cart-item__details">
                                <h3 className="cart-item__name">{item.title}</h3>
                                <p className="cart-item__category">{item.category}</p>
                                <p className="cart-item__price">${item.price.toFixed(2)}</p>
                            </div>
                            <div className="cart-item__quantity">
                                <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="qty-btn" disabled={item.quantity <= 1}>
                                    <Minus size={16} />
                                </button>
                                <span>{item.quantity}</span>
                                <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="qty-btn">
                                    <Plus size={16} />
                                </button>
                            </div>
                            <div className="cart-item__subtotal">
                                ${(item.price * item.quantity).toFixed(2)}
                            </div>
                            <button
                                className="cart-item__remove"
                                onClick={() => removeFromCart(item.id)}
                                aria-label="Remove item"
                            >
                                <Trash2 size={20} />
                            </button>
                        </div>
                    ))}
                </div>

                <aside className="cart-summary">
                    <h2 className="summary-title">Order Summary</h2>
                    <div className="summary-row">
                        <span>Subtotal</span>
                        <span>${cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="summary-row">
                        <span>Shipping</span>
                        <span>Free</span>
                    </div>
                    <div className="summary-row total">
                        <span>Total</span>
                        <span>${cartTotal.toFixed(2)}</span>
                    </div>
                    <Link to="/checkout" className="checkout-btn">
                        Proceed to Checkout <ArrowRight size={18} />
                    </Link>
                    <Link to="/shop" className="continue-shopping">
                        Continue Shopping
                    </Link>
                </aside>
            </div>
        </div>
    );
};

export default CartPage;
