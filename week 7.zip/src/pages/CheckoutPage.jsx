import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { CreditCard, Truck, ShieldCheck, ChevronRight } from 'lucide-react';
import './CheckoutPage.css';

const CheckoutPage = () => {
    const { cartItems, cartTotal, clearCart } = useCart();
    const { user } = useAuth();
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        fullName: user?.name || '',
        email: user?.email || '',
        address: '',
        city: '',
        zipCode: '',
        cardName: '',
        cardNumber: '',
        expiry: '',
        cvv: ''
    });

    const [errors, setErrors] = useState({});

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: '' }));
        }
    };

    const validate = () => {
        const newErrors = {};
        if (!formData.address) newErrors.address = 'Address is required';
        if (!formData.city) newErrors.city = 'City is required';
        if (!formData.zipCode) newErrors.zipCode = 'ZIP code is required';
        if (!formData.cardNumber) newErrors.cardNumber = 'Card number is required';
        if (!formData.cvv) newErrors.cvv = 'CVV is required';
        return newErrors;
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const validationErrors = validate();
        if (Object.keys(validationErrors).length === 0) {
            // Simulate order processing
            setTimeout(() => {
                clearCart();
                navigate('/order-success');
            }, 1500);
        } else {
            setErrors(validationErrors);
        }
    };

    return (
        <div className="container section checkout-page fade-in">
            <h1 className="checkout-title">Checkout</h1>

            <form onSubmit={handleSubmit} className="checkout-layout">
                <div className="checkout-form">
                    <section className="checkout-section">
                        <div className="section-header">
                            <Truck size={20} />
                            <h2>Shipping Information</h2>
                        </div>
                        <div className="form-grid">
                            <div className="form-group full">
                                <label>Full Name</label>
                                <input type="text" name="fullName" value={formData.fullName} onChange={handleInputChange} required />
                            </div>
                            <div className="form-group full">
                                <label>Address</label>
                                <input type="text" name="address" value={formData.address} onChange={handleInputChange} className={errors.address ? 'error' : ''} />
                                {errors.address && <span className="error-text">{errors.address}</span>}
                            </div>
                            <div className="form-group">
                                <label>City</label>
                                <input type="text" name="city" value={formData.city} onChange={handleInputChange} className={errors.city ? 'error' : ''} />
                            </div>
                            <div className="form-group">
                                <label>ZIP Code</label>
                                <input type="text" name="zipCode" value={formData.zipCode} onChange={handleInputChange} className={errors.zipCode ? 'error' : ''} />
                            </div>
                        </div>
                    </section>

                    <section className="checkout-section">
                        <div className="section-header">
                            <CreditCard size={20} />
                            <h2>Payment Method</h2>
                        </div>
                        <div className="form-grid">
                            <div className="form-group full">
                                <label>Name on Card</label>
                                <input type="text" name="cardName" value={formData.cardName} onChange={handleInputChange} required />
                            </div>
                            <div className="form-group full">
                                <label>Card Number</label>
                                <input type="text" name="cardNumber" placeholder="xxxx xxxx xxxx xxxx" value={formData.cardNumber} onChange={handleInputChange} />
                            </div>
                            <div className="form-group">
                                <label>Expiry Date</label>
                                <input type="text" name="expiry" placeholder="MM/YY" value={formData.expiry} onChange={handleInputChange} />
                            </div>
                            <div className="form-group">
                                <label>CVV</label>
                                <input type="password" name="cvv" placeholder="xxx" value={formData.cvv} onChange={handleInputChange} />
                            </div>
                        </div>
                    </section>
                </div>

                <aside className="order-summary-sidebar">
                    <h2 className="summary-title">Order Summary</h2>
                    <div className="summary-items">
                        {cartItems.map(item => (
                            <div key={item.id} className="summary-item">
                                <img src={item.image} alt={item.title} />
                                <div className="summary-item-info">
                                    <p className="item-title">{item.title}</p>
                                    <p className="item-price">{item.quantity} x ${item.price.toFixed(2)}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="summary-calculations">
                        <div className="calc-row">
                            <span>Subtotal</span>
                            <span>${cartTotal.toFixed(2)}</span>
                        </div>
                        <div className="calc-row">
                            <span>Shipping</span>
                            <span>Free</span>
                        </div>
                        <div className="calc-row total">
                            <span>Total</span>
                            <span>${cartTotal.toFixed(2)}</span>
                        </div>
                    </div>

                    <button type="submit" className="place-order-btn">
                        Place Order <ChevronRight size={18} />
                    </button>

                    <div className="secure-checkout">
                        <ShieldCheck size={16} />
                        <span>Secure 256-bit SSL encrypted payment</span>
                    </div>
                </aside>
            </form>
        </div>
    );
};

export default CheckoutPage;
