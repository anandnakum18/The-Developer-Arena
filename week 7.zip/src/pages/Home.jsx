import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ProductService } from '../services/productService';
import ProductCard from '../components/product/ProductCard';
import { ShoppingBag, ArrowRight, Zap, Award, Clock, ChevronRight } from 'lucide-react';
import './Home.css';

const Home = () => {
    const [featuredProducts, setFeaturedProducts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchFeatured = async () => {
            try {
                const data = await ProductService.getAllProducts();
                setFeaturedProducts(data.slice(0, 4)); // Show first 4 as featured
                setLoading(false);
            } catch (err) {
                setLoading(false);
            }
        };
        fetchFeatured();
    }, []);

    return (
        <div className="home-page fade-in">
            {/* Hero Section */}
            <section className="hero">
                <div className="container hero__container">
                    <div className="hero__content">
                        <span className="hero__badge">New Season Collection 2026</span>
                        <h1 className="hero__title">Elevate Your Lifestyle With <span className="text-gradient">LuxeStore</span></h1>
                        <p className="hero__subtitle">
                            Discover a curated selection of premium electronics, exquisite jewelry, and modern fashion.
                            Quality meets aesthetic excellence.
                        </p>
                        <div className="hero__actions">
                            <Link to="/shop" className="btn-hero-primary">
                                Shop Collection <ArrowRight size={20} />
                            </Link>
                            <Link to="/shop" className="btn-hero-secondary">
                                View Trends
                            </Link>
                        </div>
                    </div>
                    <div className="hero__image-placeholder">
                        <ShoppingBag size={300} color="rgba(52, 152, 219, 0.1)" strokeWidth={0.5} />
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="features section container">
                <div className="features__grid">
                    <div className="feature-card">
                        <Zap size={32} />
                        <h3>Fast Delivery</h3>
                        <p>Premium shipping on all orders worldwide.</p>
                    </div>
                    <div className="feature-card">
                        <Award size={32} />
                        <h3>Top Quality</h3>
                        <p>Hand-picked items from the world's best brands.</p>
                    </div>
                    <div className="feature-card">
                        <Clock size={32} />
                        <h3>24/7 Support</h3>
                        <p>Our dedicated team is always here to help you.</p>
                    </div>
                </div>
            </section>

            {/* Featured Products */}
            <section className="featured-products section container">
                <div className="section-header">
                    <h2>Featured Products</h2>
                    <Link to="/shop" className="view-all">View All <ChevronRight size={16} /></Link>
                </div>

                {loading ? (
                    <div className="loader-container"><div className="loader"></div></div>
                ) : (
                    <div className="product-grid">
                        {featuredProducts.map(product => (
                            <ProductCard key={product.id} product={product} />
                        ))}
                    </div>
                )}
            </section>

            {/* CTA Section */}
            <section className="cta section">
                <div className="container cta__container">
                    <div className="cta__content">
                        <h2>Join the Luxe Community</h2>
                        <p>Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.</p>
                        <div className="cta__form">
                            <input type="email" placeholder="Enter your email" />
                            <button>Subscribe</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;
