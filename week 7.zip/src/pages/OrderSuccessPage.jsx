import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ShoppingBag, ArrowRight } from 'lucide-react';

const OrderSuccessPage = () => {
    const orderNumber = Math.floor(100000 + Math.random() * 900000);

    return (
        <div className="container section fade-in" style={{ textAlign: 'center', padding: '100px 0' }}>
            <CheckCircle size={100} color="var(--color-success)" style={{ marginBottom: '30px' }} />
            <h1 style={{ fontSize: '2.5rem', marginBottom: '15px' }}>Order Placed!</h1>
            <p style={{ fontSize: '1.2rem', color: 'var(--color-text-light)', marginBottom: '10px' }}>
                Thank you for your purchase. Your order has been received.
            </p>
            <p style={{ fontWeight: '600', marginBottom: '40px' }}>
                Order Confirmation Number: <span style={{ color: 'var(--color-primary)' }}>#{orderNumber}</span>
            </p>

            <div style={{ display: 'flex', gap: '20px', justifyContent: 'center' }}>
                <Link to="/shop" style={{ background: 'var(--color-primary)', color: '#fff', padding: '12px 30px', borderRadius: 'var(--radius-md)', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <ShoppingBag size={18} /> Continue Shopping
                </Link>
                <Link to="/" style={{ color: 'var(--color-text)', border: '1px solid var(--color-border)', padding: '12px 30px', borderRadius: 'var(--radius-md)', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    Account Dashboard <ArrowRight size={18} />
                </Link>
            </div>
        </div>
    );
};

export default OrderSuccessPage;
