import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ProductService } from '../services/productService';
import { useCart } from '../contexts/CartContext';
import { Star, ShoppingCart, ArrowLeft, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import './ProductDetail.css';

const ProductDetail = () => {
    const { id } = useParams();
    const [product, setProduct] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const { addToCart } = useCart();

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                setLoading(true);
                const data = await ProductService.getProductById(id);
                setProduct(data);
                setLoading(false);
            } catch (err) {
                setError('Product not found.');
                setLoading(false);
            }
        };
        fetchProduct();
    }, [id]);

    if (loading) return <div className="container section fade-in"><div className="loader"></div></div>;
    if (error) return <div className="container section"><h2>{error}</h2><Link to="/shop">Back to Shop</Link></div>;

    return (
        <div className="container section product-detail fade-in">
            <Link to="/shop" className="back-link">
                <ArrowLeft size={18} /> Back to Shop
            </Link>

            <div className="product-detail__layout">
                <div className="product-detail__image-box">
                    <img src={product.image} alt={product.title} />
                </div>

                <div className="product-detail__info">
                    <span className="product-detail__category">{product.category}</span>
                    <h1 className="product-detail__title">{product.title}</h1>

                    <div className="product-detail__rating">
                        <div className="product-detail__stars">
                            <Star size={18} fill="var(--color-primary)" color="var(--color-primary)" />
                            <span className="rating-val">{product.rating.rate}</span>
                        </div>
                        <span className="rating-count">{product.rating.count} reviews</span>
                    </div>

                    <div className="product-detail__price">${product.price.toFixed(2)}</div>

                    <p className="product-detail__description">{product.description}</p>

                    <div className="product-detail__actions">
                        <button className="btn-add-cart" onClick={() => addToCart(product)}>
                            <ShoppingCart size={20} /> Add to Cart
                        </button>
                    </div>

                    <div className="product-detail__features">
                        <div className="feature">
                            <Truck size={20} />
                            <div>
                                <h4>Free Shipping</h4>
                                <p>On all orders over $100</p>
                            </div>
                        </div>
                        <div className="feature">
                            <RefreshCw size={20} />
                            <div>
                                <h4>Easy Returns</h4>
                                <p>30-day money back guarantee</p>
                            </div>
                        </div>
                        <div className="feature">
                            <ShieldCheck size={20} />
                            <div>
                                <h4>Secure Payment</h4>
                                <p>100% secure checkout</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductDetail;
