import React, { Suspense, lazy } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Header from './components/common/Header'
import Footer from './components/common/Footer'
import './styles/App.css'

// Lazy loaded components
const Home = lazy(() => import('./pages/Home'))
const Shop = lazy(() => import('./pages/Shop'))
const ProductDetail = lazy(() => import('./pages/ProductDetail'))
const CartPage = lazy(() => import('./pages/CartPage'))
const LoginPage = lazy(() => import('./pages/AuthPages').then(m => ({ default: m.LoginPage })))
const RegisterPage = lazy(() => import('./pages/AuthPages').then(m => ({ default: m.RegisterPage })))
const CheckoutPage = lazy(() => import('./pages/CheckoutPage'))
const OrderSuccessPage = lazy(() => import('./pages/OrderSuccessPage'))
const ProtectedRoute = lazy(() => import('./components/auth/ProtectedRoute'))

const NotFound = () => (
  <div className="container section" style={{ textAlign: 'center', padding: '100px 0' }}>
    <h1>404 - Page Not Found</h1>
    <p>The page you are looking for doesn't exist.</p>
  </div>
)

function App() {
  return (
    <Router>
      <div className="App">
        <Header />

        <main className="main-content">
          <Suspense fallback={<div className="container section center-loader"><div className="loader"></div></div>}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/cart" element={<CartPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route
                path="/checkout"
                element={
                  <Suspense fallback={<div>Loading...</div>}>
                    <ProtectedRoute>
                      <CheckoutPage />
                    </ProtectedRoute>
                  </Suspense>
                }
              />
              <Route path="/order-success" element={<OrderSuccessPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </main>

        <Footer />
      </div>
    </Router>
  )
}

export default App
