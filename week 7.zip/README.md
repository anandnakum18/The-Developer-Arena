# LuxeStore — Premium E-commerce Frontend

A high-end, fully functional E-commerce application built with **React**, **Vite**, and **Context API**. This project demonstrates advanced frontend architecture, state management, and aesthetic web design.

## 🚀 Key Features

- **Product Catalog**: Real-time data from FakeStoreAPI with category filtering and price sorting.
- **Detailed Product Views**: Comprehensive item information with rating and feature highlights.
- **Shopping Cart**: Fully functional cart with persistent state, quantity management, and subtotal calculation.
- **Authentication Simulation**: Login/Register flow with protected routes and persistent user sessions.
- **Advanced Checkout**: Multi-step simulation with form validation and order confirmation.
- **Performance Optimized**: Route-based code splitting (React.lazy), image lazy loading, and premium CSS animations.

## 🛠️ Tech Stack

- **Framework**: React 18 (Vite)
- **State Management**: Context API (Cart & Auth)
- **Routing**: React Router 6
- **Icons**: Lucide React
- **Styling**: Vanilla CSS (Modern CSS variables, Flexbox/Grid, Animations)

## 📦 Getting Started

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Run Development Server**:
   ```bash
   npm run dev
   ```

3. **Build for Production**:
   ```bash
   npm run build
   ```

## 📂 Project Structure

- `src/components/`: Reusable UI components (Common, Auth, Product)
- `src/contexts/`: Global state management (Auth, Cart)
- `src/pages/`: Main application pages (Home, Shop, Cart, etc.)
- `src/services/`: API interaction logic
- `src/styles/`: Global styles and theme tokens

---
Built as the Capstone Project for **Week 8: Full Frontend Application**.
